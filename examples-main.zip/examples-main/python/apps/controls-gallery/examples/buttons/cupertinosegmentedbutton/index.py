name = "CupertinoSegmentedButton"
description = """An iOS-style segmented button."""
