name = "MenuItemButton"
description = """A button for use in a MenuBar or on its own, that can be activated by click or keyboard navigation."""
