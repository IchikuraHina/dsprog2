name = "CupertinoDialogAction"
description = """A button typically used in a CupertinoAlertDialog."""
