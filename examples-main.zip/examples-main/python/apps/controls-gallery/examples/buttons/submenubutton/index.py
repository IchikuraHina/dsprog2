name = "SubmenuButton"
description = """A menu button that displays a cascading menu.

It can be used as part of a MenuBar, or as a standalone control."""
