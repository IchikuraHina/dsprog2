name = "Map"
description = """Used to display a map with various layers."""
