name = "Icon"
description = """Displays a Material icon."""
