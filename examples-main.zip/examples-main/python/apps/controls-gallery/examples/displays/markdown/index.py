name = "Markdown"
description = """Control for rendering text in markdown format."""
