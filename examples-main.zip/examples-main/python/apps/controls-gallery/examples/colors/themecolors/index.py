name = "Theme colors"
description = """A set of 30 colors based on the Material 3 color system that can be used to configure the color properties of most controls."""