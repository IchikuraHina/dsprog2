name = "Cupertino Colors"
description = """A palette of Color constants that describe colors commonly used when matching the iOS platform aesthetics."""
