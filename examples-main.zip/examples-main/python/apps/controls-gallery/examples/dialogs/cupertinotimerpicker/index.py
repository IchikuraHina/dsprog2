name = "CupertinoTimerPicker"
description = """A countdown timer picker in iOS style."""
