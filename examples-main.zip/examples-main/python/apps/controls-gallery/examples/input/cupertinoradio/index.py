name = "CupertinoRadio"
description = """A macOS style radio button."""
