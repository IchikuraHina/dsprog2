name = "InteractiveViewer"

description = """Allows users to pan, zoom, and rotate the provided content."""
