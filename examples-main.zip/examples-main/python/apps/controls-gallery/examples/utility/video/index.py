name = "Video"

description = """Video playing control. Based on the media_kit Dart/Flutter package."""
