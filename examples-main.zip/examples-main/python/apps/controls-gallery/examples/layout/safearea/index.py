name = "SafeArea"
description = """A control that insets its content by sufficient padding to avoid intrusions by the operating system."""
