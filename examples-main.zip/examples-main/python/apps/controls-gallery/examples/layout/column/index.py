name = "Column"
description = "A control that displays its children in a vertical array."
