name = "Placeholder"
description = """A control that draws a box that represents where other widgets will one day be added.

Useful during development to indicate that the interface is not yet complete."""
