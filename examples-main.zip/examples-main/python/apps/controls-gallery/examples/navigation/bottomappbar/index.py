name = "BottomAppBar"
description = """A material design bottom app bar."""
