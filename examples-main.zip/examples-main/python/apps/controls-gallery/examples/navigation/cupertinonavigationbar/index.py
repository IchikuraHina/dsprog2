name = "CupertinoNavigationBar"

description = """An iOS-style bottom navigation tab bar."""
