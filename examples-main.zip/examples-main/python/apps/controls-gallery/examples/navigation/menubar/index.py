name = "MenuBar"
description = """A menu bar that manages cascading child menus."""
