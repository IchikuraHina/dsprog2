name = "CupertinoAppBar"
description = """An iOS-styled application bar."""
