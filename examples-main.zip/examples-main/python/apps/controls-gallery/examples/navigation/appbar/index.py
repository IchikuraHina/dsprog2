name = "AppBar"
description = """A material design app bar."""
