# Flet Icons Browser with deployment to Fly.io

Deploy:

    flyctl deploy

Check deployment:

    flyctl status

Re-deploy:

    flyctl deploy --no-cache