import plotly.graph_objects as go

import flet
from flet import Page
from flet.plotly_chart import PlotlyChart


def main(page: Page):

    x = [
        "day 1",
        "day 1",
        "day 1",
        "day 1",
        "day 1",
        "day 1",
        "day 2",
        "day 2",
        "day 2",
        "day 2",
        "day 2",
        "day 2",
    ]

    fig = go.Figure()

    fig.add_trace(
        go.Box(
            y=[0.2, 0.2, 0.6, 1.0, 0.5, 0.4, 0.2, 0.7, 0.9, 0.1, 0.5, 0.3],
            x=x,
            name="kale",
            marker_color="#3D9970",
        )
    )
    fig.add_trace(
        go.Box(
            y=[0.6, 0.7, 0.3, 0.6, 0.0, 0.5, 0.7, 0.9, 0.5, 0.8, 0.7, 0.2],
            x=x,
            name="radishes",
            marker_color="#FF4136",
        )
    )
    fig.add_trace(
        go.Box(
            y=[0.1, 0.3, 0.1, 0.9, 0.6, 0.6, 0.9, 1.0, 0.3, 0.6, 0.8, 0.5],
            x=x,
            name="carrots",
            marker_color="#FF851B",
        )
    )

    fig.update_layout(
        yaxis_title="normalized moisture",
        boxmode="group",  # group together boxes of the different traces for each value of x
    )

    page.add(PlotlyChart(fig, expand=True))


flet.app(target=main)
